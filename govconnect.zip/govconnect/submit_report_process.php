<?php
session_start();
require_once "db_connect.php"; // Database connection

// Only logged-in users with role 'user' can submit
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $suggestion = trim($_POST['suggestion'] ?? '');
    $priority = trim($_POST['priority']);
    $location = trim($_POST['location']); // expects "lat,lng"

    // Validate location
    if (empty($location)) {
        echo "<script>alert('❌ Please select a location on the map'); window.history.back();</script>";
        exit;
    }

    // Prepare SQL statement
    $stmt = $pdo->prepare("INSERT INTO problems (user_id, category, description, suggestion, location, priority) VALUES (:user_id, :category, :description, :suggestion, :location, :priority)");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':suggestion', $suggestion);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':priority', $priority);

    try {
        $stmt->execute();
        echo "<script>alert('✅ Report submitted successfully!'); window.location='dashboard.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('❌ Error submitting report: " . $e->getMessage() . "'); window.history.back();</script>";
    }
}
?>
