<?php
session_start();
require_once "db_connect.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='response'){
    header("Location: login.php");
    exit;
}

// Fetch problems assigned to this response team member
$stmt = $mysqli->prepare("SELECT r.response_id, p.problem_id, u.name as user_name, p.category, p.description, p.location, p.priority, p.status, p.suggestion, r.status_update
                          FROM responses r
                          JOIN problems p ON r.problem_id = p.problem_id
                          JOIN users u ON p.user_id = u.user_id
                          WHERE r.responder_id=? ORDER BY r.created_at DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Response Panel - GovConnect</title>
<style>
body{font-family: Arial; background:#f4f6f9; margin:0; padding:0;}
.header{padding:15px; background:#1e3c72; color:#fff; text-align:center;}
table{width:95%; margin:20px auto; border-collapse: collapse; background:#fff;}
th,td{padding:10px; border:1px solid #ccc; text-align:left;}
th{background:#1e3c72; color:#fff;}
a.button{padding:5px 10px; background:#27ae60; color:#fff; text-decoration:none; border-radius:4px;}
a.button:hover{background:#2ecc71;}
</style>
</head>
<body>

<div class="header">
  <h2>Response Team Dashboard</h2>
  <p>Welcome, <?php echo $_SESSION['name']; ?> | <a href="logout.php" style="color:#fff;">Logout</a></p>
</div>

<table>
<tr>
<th>ID</th>
<th>User</th>
<th>Category</th>
<th>Description</th>
<th>Location</th>
<th>Priority</th>
<th>Status</th>
<th>Suggestion</th>
<th>Action Update</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
<td><?php echo $row['problem_id']; ?></td>
<td><?php echo $row['user_name']; ?></td>
<td><?php echo ucfirst($row['category']); ?></td>
<td><?php echo $row['description']; ?></td>
<td><?php echo $row['location']; ?></td>
<td><?php echo ucfirst($row['priority']); ?></td>
<td><?php echo ucfirst($row['status']); ?></td>
<td><?php echo $row['suggestion']; ?></td>
<td>
    <a href="response_action.php?id=<?php echo $row['response_id']; ?>&status=on_route" class="button">On Route</a>
    <a href="response_action.php?id=<?php echo $row['response_id']; ?>&status=resolved" class="button" style="background:#2c3e50;">Resolved</a>
    <a href="response_action.php?id=<?php echo $row['response_id']; ?>&status=rejected" class="button" style="background:#e74c3c;">Reject</a>
</td>
</tr>
<?php endwhile; ?>

</table>

</body>
</html>
